# QilaPay — Remittance adaptif di Tempo Testnet

Aplikasi web pengiriman uang internasional yang menyelesaikan dana di **Tempo Testnet
(Moderato)** dalam hitungan detik, dengan kurs transparan dan **KYC adaptif** —
verifikasi naik hanya saat dibutuhkan (pendekatan ala Roblox).

> **Testnet demo.** Uang tidak nyata. Provider KYC disimulasikan. Banner "Testnet Demo"
> tampil di semua halaman.

---

## Yang sudah jalan (diverifikasi end-to-end di Moderato)

| # | Skenario | Hasil |
|---|----------|-------|
| 1 | Sari kirim $20 | `ALLOW` → settled ±1–3 detik, **tanpa layar KYC** |
| 2 | Sari kirim $200 | `STEP_UP` (LIMIT_PER_TX, LIMIT_ROLLING_30D, NEW_RECIPIENT_LARGE) → pilih metode → Simulate: Approve → transfer lanjut otomatis + tier naik |
| 3 | Dewi (riwayat velocity) | `STEP_UP` VELOCITY_HIGH padahal nominal kecil |
| 4 | Penerima di screening list | `HOLD_REVIEW` → admin approve/reject di konsol → eksekusi on-chain |
| 5 | IDR → EUR | Kurs terkunci 60s + countdown, mode **Treasury fallback** (DEX belum punya pair non-USD), 2 leg on-chain |
| 6 | Penerima daftar sanksi | `BLOCK` otomatis (SANCTIONS_BLOCK) |

Setiap transfer settled punya **tx hash yang bisa dibuka di explorer**, memo on-chain
`QILA-<id>` yang cocok dengan record DB, dan waktu settlement akurat
("Settled in X.XX detik").

## Cara menjalankan

```bash
bun install
bun run db:push        # push schema Prisma (SQLite)
bun run dev            # dev server otomatis di port 3000
```

Buka aplikasi → klik **"Try demo"** (masuk sebagai Sari) atau **Demo** untuk halaman
demo center. Seed pertama otomatis: issue token qIDR/qSGD/qEUR/qGBP on-chain via TIP-20
Factory, faucet treasury, dan membuat 4 persona.

### Login cepat (persona)

| Persona | Tier | Skenario |
|---|---|---|
| `sari@qilapay.demo` | 0 | kirim kecil lolos / kirim besar step-up |
| `budi@qilapay.demo` | 2 | transfer lintas mata uang tanpa hambatan |
| `dewi@qilapay.demo` | 0 | velocity trigger |
| `admin@qilapay.demo` | 2 (admin) | konsol compliance |

Password bebas untuk persona (login persona tidak cek password). Registrasi akun baru
(password min. 8 karakter) otomatis membuat wallet kustodial yang didanai faucet.

## Halaman (SPA — semua view dari satu route)

- **Landing** — hero, fitur, penjelasan KYC adaptif
- **Dashboard** — saldo on-chain live per mata uang, progress limit tier, transfer terakhir, top up
- **Kirim** — wizard: quote (kurs terkunci 60s + countdown) → compliance/step-up → hasil
- **Transfers** — riwayat + detail dengan timeline event dan link explorer
- **Verifikasi** — pilih metode, status, tombol Simulate (DEMO_MODE)
- **Penerima** — user QilaPay via email atau wallet eksternal Tempo
- **Admin** — antrean review, monitor transfer, risk decisions + snapshot, editor limit/spread/koridor
- **Demo** — persona satu klik, 6 skenario siap pakai, reset, script 3 menit, ringkasan teknis

## Arsitektur

- **Frontend**: Next.js 16 App Router + TypeScript + Tailwind 4 + shadcn/ui.
  Satu halaman SPA (`src/app/page.tsx`) dengan view switching — navigasi tanpa reload.
- **Backend**: Next.js API routes (`src/app/api/*`) + Prisma (SQLite).
  Semua operasi sensitif (dekripsi kunci, eksekusi on-chain) hanya di server.
- **Blockchain**: `viem` + modul `viem/tempo` (Actions.token, Actions.dex, Abis, Addresses).
- **Kurs**: Frankfurter API (ECB, tanpa API key), cache 5 menit di tabel `fx_rates`.

### Eksekusi transfer (spec 6.4)

```
same-ccy : user wallet ──transferWithMemo──▶ recipient            (1 tx)
cross-ccy: try DEX quote (Stablecoin DEX 0xdec0…)
           ├─ pair tersedia  : user swap via DEX → kirim ke penerima
           └─ PairDoesNotExist / InsufficientLiquidity (kasus nyata hari ini):
                 user ──debit──▶ treasury ──kredit q<CCY>──▶ recipient  (2 tx)
```

- Memo on-chain: `QILA-<10 karakter terakhir transfer id>` (32-byte, terbaca di explorer).
- Fee transaksi dibayar dari saldo stablecoin wallet (wallet didanai faucet saat
  dibuat); treasury adalah issuer q-token sehingga inventory selalu bisa di-top-up
  (mint) sebelum kredit.
- `executionMode` tampil jujur di UI: `DEX Tempo` / `Treasury fallback` / `Transfer langsung`.

### Keamanan

- Private key wallet dienkripsi **AES-256-GCM** (`WALLET_ENCRYPTION_KEY`), hanya
  didekripsi di server saat eksekusi. Tidak pernah dikirim ke browser.
- Service-role operation (eksekusi, mint, faucet) hanya lewat API route.
- Session cookie httpOnly bertanda tangan HMAC.

## Environment variables

```
DATABASE_URL=                    # SQLite (sudah diisi)
TEMPO_RPC_URL=https://rpc.moderato.tempo.xyz
TEMPO_CHAIN_ID=42431
TEMPO_EXPLORER_URL=https://explore.testnet.tempo.xyz
TEMPO_FAUCET_URL=https://tempo.xyz/developers/api/faucet
TREASURY_PRIVATE_KEY=0x…         # wallet treasury/issuer
WALLET_ENCRYPTION_KEY=…          # AES key derivation (32 byte hex)
DEMO_MODE=true                   # mengaktifkan tombol Simulate
SESSION_SECRET=…
```

## Alamat on-chain (Moderato, chain 42431)

| Token | Address |
|---|---|
| pathUSD (USD) | `0x20c0000000000000000000000000000000000000` |
| qIDR | `0x20c000000000000000000000b975a83327b8af05` |
| qSGD | `0x20c000000000000000000000335b00c2a7a01925` |
| qEUR | `0x20c0000000000000000000002a21872b909c9e5c` |
| qGBP | `0x20c0000000000000000000002942fd521bffd2f8` |

Predeploy yang dipakai: TIP-20 Factory `0x20fc…0000`, Stablecoin DEX `0xdec0…0000`.
Faucet: `POST https://tempo.xyz/developers/api/faucet` atau RPC `tempo_fundAddress`.

Alamat token juga tampil live di halaman **Demo → Ringkasan teknis** (dari DB).

## Skema database (Prisma — padanan spec Supabase)

`User`(+`UserRole`), `KycTierConfig`, `KycVerification`, `Wallet`, `Currency`,
`FxRate`, `Recipient`, `Quote`, `Transfer`(+`TransferEvent`), `RiskDecision`,
`ScreeningEntry`, `AppConfig`, `AuditLog`. Rolling 30-day usage dihitung via join
`Transfer → Quote.usdEquivalent` (setara view `v_rolling_usage`).

**Semua angka bisnis dari database/config** — limit tier (`kyc_tier_config`), spread
& fee (`app_config`: `fx_spread_bps`, `fee_bps`), ambang velocity, penerima baru,
koridor risiko — bisa diedit admin di konsol tanpa deploy ulang.

## Decision engine (spec 5.3)

`evaluateTransfer()` → `ALLOW | STEP_UP (+metode) | HOLD_REVIEW | BLOCK`
dengan reason code + snapshot input yang tersimpan di `risk_decisions`:

- `LIMIT_PER_TX`, `LIMIT_ROLLING_30D` → step-up ke tier minimum yang cukup
- `VELOCITY_HIGH` (≥3 transfer / 10 menit), `NEW_RECIPIENT_LARGE` → step-up
- `CORRIDOR_RISK`, `SCREENING_HIT` → hold review
- `SANCTIONS_BLOCK` → block

Panel **"Kenapa saya diminta verifikasi?"** menampilkan reason code dalam bahasa
manusia. Metode verifikasi alternatif: selfie liveness, estimasi usia, dokumen +
face match, micro-deposit bank, bukti alamat, sumber dana, video call.

## Di luar cakupan

Uang nyata, KYC provider produksi, kepatuhan regulasi (lisensi, travel rule),
mainnet, off-ramp bank, aplikasi mobile native. `KycProvider` interface siap
ditukar ke Persona/Sumsub sandbox tanpa mengubah flow.

## Catatan implementasi vs spec

- Supabase dipadankan ke Prisma/SQLite + cookie auth (lingkungan sandbox tidak
  punya Supabase). Konsep RLS dipadankan: filter `userId` di setiap query + admin
  guard di route admin.
- Halaman multi-route dari spec dipadankan ke SPA single-route (batasan preview
  sandbox); semua fungsi tetap ada.
- Milestone inti yang wajib sempurna (3, 5, 6, 8) sudah jalan end-to-end dan
  diverifikasi di browser + on-chain.
